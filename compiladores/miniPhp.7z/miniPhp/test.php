/* Comentario 
en 
#varias
lineas */
# Comentario de una linea
<?php
$a = '';
$c = 565161661;
echo "";
?>